###################################################
### chunk number 1: preliminaries
###################################################
library("rootSolve")
options(prompt = "> ")
options(width=70)



###################################################
### chunk number 2: fig1plot
###################################################
  fun <- function (x) cos(2*x)^3
  curve(fun(x),0,8)
  abline(h=0,lty=3)
  uni <- uniroot(fun,c(0,8))$root
  points(uni,0,pch=16,cex=2)


###################################################
### chunk number 3: fig1
###################################################
  fun <- function (x) cos(2*x)^3
  curve(fun(x),0,8)
  abline(h=0,lty=3)
  uni <- uniroot(fun,c(0,8))$root
  points(uni,0,pch=16,cex=2)


###################################################
### chunk number 4: uniall
###################################################
  curve(fun(x),0,8)
  abline(h=0,lty=3)
  All <- uniroot.all(fun,c(0,8))
  points(All,y=rep(0,length(All)),pch=16,cex=2)


###################################################
### chunk number 5: fig2
###################################################
  curve(fun(x),0,8)
  abline(h=0,lty=3)
  All <- uniroot.all(fun,c(0,8))
  points(All,y=rep(0,length(All)),pch=16,cex=2)


###################################################
### chunk number 6: 
###################################################
model <- function(x) {
F1=x[1] + x[2] + x[3]^2 -12
F2=x[1]^2 -x[2] + x[3] -2
F3=2*x[1] -x[2]^2 + x[3] -1
c(F1=F1,F2=F2,F3=F3)
}

# first solution
(ss<-multiroot(f=model,start=c(1,1,1)))

# second solution; use different start values
(ss2<-multiroot(model,c(0,0,0)))$root
model(ss2$root)   # the function value at the root


###################################################
### chunk number 7: 
###################################################
f2<-function(x)
 {
 X<-matrix(nr=5,x)
 X %*% X %*% X -matrix(nr=5,data=1:25,byrow=TRUE)
 }
x<-multiroot(f2, start=1:25)$root
(X<-matrix(nr=5,x))

X%*%X%*%X


###################################################
### chunk number 8: 
###################################################
 model<-function(t,y,pars)
{
  with (as.list(c(y,pars)),{

  oxicmin   = r*OM*(O2/(O2+ks))
  anoxicmin = r*OM*(1-O2/(O2+ks))* SO4/(SO4+ks2)

  dOM  = Flux - oxicmin - anoxicmin
  dO2  = -oxicmin      -2*rox*HS*(O2/(O2+ks)) + D*(BO2-O2)
  dSO4 = -0.5*anoxicmin  +rox*HS*(O2/(O2+ks)) + D*(BSO4-SO4)
  dHS  = 0.5*anoxicmin   -rox*HS*(O2/(O2+ks)) + D*(BHS-HS)

  list(c(dOM,dO2,dSO4,dHS),SumS=SO4+HS)
})
}


###################################################
### chunk number 9: 
###################################################
pars <- c(D=1,Flux=100,r=0.1,rox =1,
          ks=1,ks2=1,BO2=100,BSO4=10000,BHS = 0)

y<-c(OM=1,O2=1,SO4=1,HS=1)

runsteady(y=y,fun=model,parms=pars,times=c(0,1e5))$y


###################################################
### chunk number 10: 
###################################################
stode(y=y,fun=model,parms=pars,pos=TRUE)


###################################################
### chunk number 11: 
###################################################
  derivs <- function(t,y,parms, x,dx,N,y1,y6)
  {

   d2y <- (c(y[-1],y6) -2*y + c(y1,y[-N])) /dx/dx
   dy  <- (c(y[-1],y6) - c(y1,y[-N])) /2/dx

   res <- d2y+dy/x+(1-1/(4*x*x))*y-sqrt(x)*cos(x)
   return(list(res))
  }


###################################################
### chunk number 12: 
###################################################
dx     <- 0.001
x      <- seq(1,6,by=dx)
N      <- length(x)
y  <- steady.band(y=rep(1,N),time=0,func=derivs,x=x,dx=dx,
                  N=N,y1=1,y6=-0.5,nspec=1)$y


###################################################
### chunk number 13: steady1D
###################################################
plot(x,y,type="l",main="5001 nonlinear equations - banded Jacobian")

curve(0.0588713*cos(x)/sqrt(x)+1/4*sqrt(x)*cos(x)+
       0.740071*sin(x)/sqrt(x)+1/4*x^(3/2)*sin(x),add=TRUE,type="p")

legend("topright",pch=c(NA,1),lty=c(1,NA),c("numeric","analytic"))


###################################################
### chunk number 14: steady1D
###################################################
plot(x,y,type="l",main="5001 nonlinear equations - banded Jacobian")

curve(0.0588713*cos(x)/sqrt(x)+1/4*sqrt(x)*cos(x)+
       0.740071*sin(x)/sqrt(x)+1/4*x^(3/2)*sin(x),add=TRUE,type="p")

legend("topright",pch=c(NA,1),lty=c(1,NA),c("numeric","analytic"))


###################################################
### chunk number 15: 
###################################################
O2BOD <- function(t,state,pars)
{
  BOD <- state[1:N]
  O2  <- state[(N+1):(2*N)]

  FluxBOD <-  v*c(BOD_0,BOD)  # fluxes due to water transport
  FluxO2  <-  v*c(O2_0,O2)

  BODrate <- r*BOD*O2/(O2+10)  # 1-st order consumption, Monod in oxygen

#rate of change = -flux gradient - consumption  + reaeration (O2)
  dBOD         <- -diff(FluxBOD)/dx  - BODrate
  dO2          <- -diff(FluxO2)/dx   - BODrate + p*(O2sat-O2)

  return(list(c(dBOD=dBOD,dO2=dO2),BODrate=BODrate))
 }


###################################################
### chunk number 16: 
###################################################
dx      <- 10        # grid size, meters
v       <- 1e2       # velocity, m/day
r       <- 0.1       # /day, first-order decay of BOD
p       <- 0.1       # /day, air-sea exchange rate
O2sat   <- 300       # mmol/m3 saturated oxygen conc
O2_0    <- 50        # mmol/m3 riverine oxygen conc
BOD_0   <- 1500      # mmol/m3 riverine BOD concentration

x       <- seq(dx/2,10000,by=dx)  # m, distance from river
N       <- length(x)

state <- c(rep(200,N),rep(200,N))    # initial guess of state variables:

out   <- steady.1D (y=state,func=O2BOD,parms=NULL, nspec=2,pos=TRUE)


###################################################
### chunk number 17: BOD
###################################################
mf <- par(mfrow=c(2,2))
plot(x,out$y[(N+1):(2*N)],xlab= "Distance from river",
     ylab="mmol/m3",main="Oxygen",type="l")

plot(x,out$y[1:N],xlab= "Distance from river",
     ylab="mmol/m3",main="BOD",type="l")

plot(x,out$BODrate,xlab= "Distance from river",
     ylab="mmol/m3/d",main="BOD decay rate",type="l")
par(mfrow=mf)


###################################################
### chunk number 18: figBOD
###################################################
mf <- par(mfrow=c(2,2))
plot(x,out$y[(N+1):(2*N)],xlab= "Distance from river",
     ylab="mmol/m3",main="Oxygen",type="l")

plot(x,out$y[1:N],xlab= "Distance from river",
     ylab="mmol/m3",main="BOD",type="l")

plot(x,out$BODrate,xlab= "Distance from river",
     ylab="mmol/m3/d",main="BOD decay rate",type="l")
par(mfrow=mf)


###################################################
### chunk number 19: 
###################################################
diffusion2D <- function(t,conc,par)
  {
   Conc     <- matrix(nr=n,nc=n,data=conc)  # vector to 2-D matrix
   dConc    <- -r*Conc*Conc    # consumption
   BND   <- rep(1,n)           # boundary concentration

   # constant production in certain cells
   dConc[ii]<-   dConc[ii]+  p

   #diffusion in X-direction; boundaries=imposed concentration

   Flux  <- -Dx * rbind(rep(0,n),(Conc[2:n,]-Conc[1:(n-1),]),rep(0,n))/dx
   dConc <- dConc - (Flux[2:(n+1),]-Flux[1:n,])/dx

   #diffusion in Y-direction
   Flux  <- -Dy * cbind(rep(0,n),(Conc[,2:n]-Conc[,1:(n-1)]),rep(0,n))/dy
   dConc <- dConc - (Flux[,2:(n+1)]-Flux[,1:n])/dy

   return(list(as.vector(dConc)))
  }


###################################################
### chunk number 20: 
###################################################
  # parameters
  dy    <- dx <- 1    # grid size
  Dy    <- Dx <- 1.5  # diffusion coeff, X- and Y-direction
  r     <- 0.01       # 2-nd-order consumption rate (/time)
  p     <- 20         # 0-th order production rate (CONC/t)
  n     <- 100
  # 10 random cells where substance is produced at rate p
  ii    <- trunc(cbind(runif(10)*n+1,runif(10)*n+1))


###################################################
### chunk number 21: 
###################################################
  Conc0 <- matrix(nr=n,nc=n,10.)

  ST3  <- steady.2D(Conc0,func=diffusion2D,parms=NULL,pos=TRUE,dimens=c(n,n),
                 lrw=1000000,atol=1e-10,rtol=1e-10,ctol=1e-10)
  Conc <- matrix(nr=n,nc=n,data=ST3$y)


###################################################
### chunk number 22: steady2D
###################################################
filled.contour(Conc,color.palette=terrain.colors)


###################################################
### chunk number 23: fig2D
###################################################
filled.contour(Conc,color.palette=terrain.colors)


###################################################
### chunk number 24: 
###################################################
# the banana function
   fun <- function(x)  100*(x[2] - x[1]^2)^2 + (1 - x[1])^2
# the minimum
   mm  <-nlm(fun, p=c(0,0))$estimate
# the Hessian
   (Hes <- hessian(fun,mm))
# the gradient
   (grad <- gradient(fun,mm,centered=TRUE))
# Hessian and gradient can also be estimated by nlm:
   nlm(fun, p=c(0,0), hessian=TRUE)


###################################################
### chunk number 25: 
###################################################
   solve(Hes)


###################################################
### chunk number 26: 
###################################################
mod <- function (t=0,y, parms=NULL,...)
{
 dy1<-  y[1] + 2*y[2]
 dy2<-3*y[1] + 4*y[2] + 5*y[3]
 dy3<-         6*y[2] + 7*y[3] + 8*y[4]
 dy4<-                  9*y[3] +10*y[4]
 return(as.list(c(dy1,dy2,dy3,dy4)))
}
jacobian.full(y=c(1,2,3,4),func=mod)
jacobian.band(y=c(1,2,3,4),func=mod)


