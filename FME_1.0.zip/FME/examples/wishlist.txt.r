Things to do.

1. further TEST mcmc
2. plot sensFun: separate lines for different variables, also if input is of type modCost

3. 2-D models @#$%
