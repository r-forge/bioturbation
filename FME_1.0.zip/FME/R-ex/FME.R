### Name: FME-package
### Title: Flexible Modelling Environment - Utility functions for models
###   consisting of differential equations
### Aliases: FME-package FME
### Keywords: package

### ** Examples

## Not run: 
##D ## show examples (see respective help pages for details)
##D example(modCost)
##D example(sensFun)
##D 
##D ## open the directory with documents
##D browseURL(paste(system.file(package="FME"), "/doc", sep=""))
##D 
##D ## the vignette
##D vignette("FME")
##D 
##D edit(vignette("FME"))
## End(Not run)



