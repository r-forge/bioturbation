### Name: modMCMC
### Title: Constrained Markov Chain Monte Carlo
### Aliases: modMCMC summary.modMCMC plot.modMCMC pairs.modMCMC
###   hist.modMCMC
### Keywords: utilities

### ** Examples


#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# testing: sampling a distribution
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# test 1: sampling a normal distribution, mean=1:3, sd = 0.25

NN <- function(p)
{
mu <- c(1,2,3)
-2*sum(log(dnorm(p,mean=mu,sd=0.1)))      #-2*log(probability)
}

# no bounds imposed...

MCMC <- modMCMC (f=NN,p=0:2, niter=10000,
                 outputlength=1000,jump=0.5)

# More accepted values by updating the jump covariance matrix...
MCMC <- modMCMC (f=NN,p=0:2, niter=10000,updatecov=100,
                 outputlength=1000,jump=0.1)
summary(MCMC)

plot(MCMC)   # check convergence
pairs(MCMC)

# bounds imposed...
NN <- function(p)
{
mu <- c(1,2,3)
-2*sum(log(dnorm(p,mean=mu,sd=0.5)))      #-2*log(probability)
}
MCMC2 <- modMCMC (f=NN,p=0:2+0.1, niter=10000,burninlength=2500,
                  outputlength=1000,jump=0.7, lower=-3:-1,upper=6:8)
plot(MCMC2)
# function from package coda...
cumuplot(as.mcmc(MCMC2$pars))
summary(MCMC2)

# test 2: sampling a log-normal distribution, log mean=1:4, log sd = 1

NL <- function(p)
{
mu <- 1:4
-2*sum(log(dlnorm(p,mean=mu,sd=1)))      #-2*log(probability)
}
MCMCl <- modMCMC (f=NL,p=log(1:4),niter=10000,outputlength=1000,jump=5)
plot(MCMCl)   # bad convergence
cumuplot(as.mcmc(MCMCl$pars))

MCMCl <- modMCMC (f=NL,p=log(1:4),niter=10000,outputlength=1000,jump=2^(2:5))
plot(MCMCl)   # better convergence but CHECK it!
pairs(MCMCl)
colMeans(log(MCMCl$pars))
sd(log(MCMCl$pars))

MCMCl <- modMCMC (f=NL,p=rep(1,4),niter=5000,outputlength=1000,
         jump=5,updatecov=100)
plot(MCMCl)
colMeans(log(MCMCl$pars))
sd(log(MCMCl$pars))

#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
# example : Fitting a Monod (Michaelis-Menten) function to data
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

# the observations
#---------------------
Obs <- data.frame(x=c(   28,  55,   83,  110,  138,  225,  375),   # mg COD/l
                  y=c(0.053,0.06,0.112,0.105,0.099,0.122,0.125))   # 1/hour
plot(Obs,pch=16,cex=2,xlim=c(0,400),ylim=c(0,0.15),
     xlab="mg COD/l",ylab="1/hr",main="Monod")

# the Monod model
#---------------------
Model <- function(p,x)   data.frame(x=x,N=p[1]*x/(x+p[2]))

# Fitting the model to the data
#---------------------
# define the residual function
Residuals  <- function(p) (Obs$y-Model(p,Obs$x)$N)  #... model residuals

# use modFit to find parameters
P      <- modFit(f=Residuals,p=c(0.1,1))

# plot best-fit model
x      <-0:375
lines(Model(P$par,x))

# summary of fit
sP    <- summary(P)
sP[]
print(sP)

# Running an MCMC
#---------------------
# estimate parameter covariances
# (to efficiently generate new parameter values)
Covar   <- sP$cov.scaled * 2.4^2/2

# the model variance
s2prior <- sP$modVariance

# set nprior = 0 to avoid updating model variance
MCMC <- modMCMC(f=Residuals,p=P$par,jump=Covar,niter=10000,
                var0=s2prior,wvar0=NULL,updatecov=100)

plot(MCMC,Full=TRUE)
pairs(MCMC)
# function from the coda package.
raftery.diag(as.mcmc(MCMC$pars))
cor(MCMC$pars)

cov(MCMC$pars)   # covariances by MCMC
sP$cov.scaled    # covariances by hessian of fit

x  <- 1:400
SR <- summary(sensRange(parInput=MCMC$pars,func=Model,x=x))
plot(SR, xlab="mg COD/l",ylab="1/hr",main="Monod")
points(Obs,pch=16,cex=1.5)




