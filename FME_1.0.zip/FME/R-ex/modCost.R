### Name: modCost
### Title: Calculates the Discrepancy of a Model Solution with Observations
### Aliases: modCost
### Keywords: utilities

### ** Examples


#======================================#
# Type 1 input:  name, time, value
#======================================#

# Create new data: two observed variables, "a", "b"
Data  <-data.frame(name=c(rep("a",4),rep("b",4)),
                   time=c(1:4,2:5),val=c(runif(4),1:4))

# "a nonsense model"
Mod <- function (t,y,par)
{
 da <- 0
 db <- 1
 return(list(c(da,db)))
}

out <- ode(y=c(a=0.5,b=0.5),times=0:6,func=Mod,parms=NULL)

Data   # Show
out

# The cost function
modCost(model=out,obs=Data,y="val")

#==============================================================#
# Type 2 input:  Matrix format; column names = variable names
#==============================================================#

# logistic growth model
TT    <- seq(1,100,2.5)
N0    <- 0.1
r     <- 0.5
K     <- 100

## analytical solution
Ana <- cbind(time=TT,N=K/(1+(K/N0-1)*exp(-r*TT)))

plot(TT, Ana[,"N"], ylim=c(0, 120),  type="l", col="red", lwd=2,
     main = "logistic growth", xlab="time", ylab="N")

## numeric solution
logist <- function(t, x, parms) {
  with(as.list(parms), {
    dx <- r * x[1] * (1 - x[1]/K)
    list(dx)
  })
}

time  <- 0:100
parms <- c(r = r, K = K)
x     <- c(N = N0)

## Compare several numerical solutions
Euler <-        euler(x, time, logist, parms, hini=2)
Rk4   <-          rk4(x, time, logist, parms, hini=2)
Ode   <-          ode(x, time, logist, parms)
Ana2  <- cbind(time=time,N=K/(1+(K/N0-1)*exp(-r*time)))

## the SSR and residuals with respect to the "data"
cEuler <- modCost(Euler,Ana)$model
cRk4   <- modCost(Rk4  ,Ana)$model
cOde   <- modCost(Ode  ,Ana)$model
cAna   <- modCost(Ana2 ,Ana)$model
compare <- data.frame(method=c("euler","rk4","ode","Ana"),
                      cost=c(cEuler,cRk4,cOde,cAna))

points(Euler,col="red")
points(Rk4,col="blue")

legend("bottomright", c("exact","euler","rk4"),pch=c(NA,1,1),
      col=c("red","red","blue"),lty=c(1,NA,NA))
legend("right",ncol=2,title="SSR",
      legend=c(as.character(compare[,1]),format(compare[,2],digits=2)))

compare

#==============================================================#
# Now suppose we do not know K and r and they are to be fitted...
#==============================================================#
# The "observations" are the analytical solution

# Run the model with initial guess: K=10, r=2
parms["K"]<-10
parms["r"]<-2
init <-  ode(x, time, logist, parms)

# show results, compared with "observations"
plot(TT, Ana[,"N"], ylim=c(0, 120),  type="p", col="red", pch=16,cex=2,
     main = "logistic growth", xlab="time", ylab="N")

lines (init  ,lwd=2,col="green")

# FITTING algorithm uses modFit
# First define the objective function (model cost) to be minimised

# more general: using modFit
Cost <- function(P)
{
 parms["K"]<-P[1]
 parms["r"]<-P[2]
 out <- ode(x, time, logist, parms)
 return(modCost(out,Ana))
}
(Fit<-modFit(p=c(K=10,r=2),f=Cost))

summary(Fit)

# run model with the optimized value:
parms[c("K","r")]<-Fit$par
fitted <-  ode(x, time, logist, parms)

lines (fitted,lwd=2,col="blue")

legend("right",c("initial","fitted"),col=c("green","blue"),lwd=2)

Cost(Fit$par)




