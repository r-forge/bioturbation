###################################################
### chunk number 1: preliminaries
###################################################
library("FME")
options(prompt = "> ")
options(width=70)


###################################################
### chunk number 2: 
###################################################
pars <- list(gmax =0.5,eff = 0.5,
              ks =0.5, rB =0.01, dB =0.01)


###################################################
### chunk number 3: 
###################################################
solveBact <- function(pars, times=seq(0,50,by=0.5))
{
 derivs <- function(t,state,pars)     # returns rate of change
  {
  with (as.list(c(state,pars)), {

  dBact = gmax*eff*Sub/(Sub+ks)*Bact - dB*Bact - rB*Bact
  dSub  =-gmax    *Sub/(Sub+ks)*Bact + dB*Bact

  return(list(c(dBact,dSub)))
                              })
  }

 state   <- c(Bact=0.1,Sub = 100)
 # ode solves the model by integration...
 return(as.data.frame(ode(y=state,times=times,func=derivs,parms=pars)))
}


###################################################
### chunk number 4: 
###################################################
out <- solveBact(pars)


###################################################
### chunk number 5: ode
###################################################
plot(out$time,out$Bact,ylim=range(c(out$Bact,out$Sub)),
     xlab="time, hour",ylab="molC/m3",type="l",lwd=2)
lines(out$time,out$Sub,lty=2,lwd=2)
lines(out$time,out$Sub+out$Bact)

legend("topright",c("Bacteria","Glucose","TOC"),
       lty=c(1,2,1),lwd=c(2,2,1))


###################################################
### chunk number 6: odefig
###################################################
plot(out$time,out$Bact,ylim=range(c(out$Bact,out$Sub)),
     xlab="time, hour",ylab="molC/m3",type="l",lwd=2)
lines(out$time,out$Sub,lty=2,lwd=2)
lines(out$time,out$Sub+out$Bact)

legend("topright",c("Bacteria","Glucose","TOC"),
       lty=c(1,2,1),lwd=c(2,2,1))


###################################################
### chunk number 7: 
###################################################
parRanges <- data.frame(min=c(0.4,0.4,0.),max=c(0.6,0.6,0.02))
rownames(parRanges)<- c("gmax","eff","rB")
parRanges


###################################################
### chunk number 8: 
###################################################
tout    <- 0:50
print(system.time(
sR<-sensRange(func=solveBact,parms=pars,dist="grid",
                sensvar=c("Bact","Sub"),parRange=parRanges[3,],num=50)
))
head(summary(sR))


###################################################
### chunk number 9: sens
###################################################
par(mfrow=c(2,2))
plot(summary(sR),main="Sensitivity rB",xlab="time, hour",ylab="molC/m3",
    legpos="topright")
plot(summary(sR),main="Sensitivity rB",xlab="time, hour",ylab="molC/m3",
     quant=TRUE,col=c("lightblue","darkblue"),legpos="topright")
par(mfrow=c(1,1))


###################################################
### chunk number 10: sensfig
###################################################
par(mfrow=c(2,2))
plot(summary(sR),main="Sensitivity rB",xlab="time, hour",ylab="molC/m3",
    legpos="topright")
plot(summary(sR),main="Sensitivity rB",xlab="time, hour",ylab="molC/m3",
     quant=TRUE,col=c("lightblue","darkblue"),legpos="topright")
par(mfrow=c(1,1))


###################################################
### chunk number 11: 
###################################################
Sens2 <- summary(sensRange(func=solveBact,parms=pars,
             dist="latin",sensvar="Bact",parRange=parRanges,num=100))


###################################################
### chunk number 12: sens2
###################################################
plot(Sens2,main="Sensitivity gmax,eff,rB",xlab="time, hour",ylab="molC/m3")


###################################################
### chunk number 13: sensfig2
###################################################
plot(Sens2,main="Sensitivity gmax,eff,rB",xlab="time, hour",ylab="molC/m3")


###################################################
### chunk number 14: 
###################################################
SnsBact<- sensFun(func=solveBact,parms=pars,
                   sensvar="Bact",varscale=1)
head(SnsBact)


###################################################
### chunk number 15: sfun
###################################################
plot(SnsBact)



###################################################
### chunk number 16: sfunfig
###################################################
plot(SnsBact)



###################################################
### chunk number 17: 
###################################################
summary(SnsBact)


###################################################
### chunk number 18: 
###################################################
summary(sensFun(solveBact,pars,varscale=1),var=TRUE)


###################################################
### chunk number 19: 
###################################################
cor(SnsBact[,-(1:2)])



###################################################
### chunk number 20: pairs
###################################################
pairs(SnsBact)


###################################################
### chunk number 21: pairsfig
###################################################
pairs(SnsBact)


###################################################
### chunk number 22: 
###################################################
SF <- function (pars)
{
  out <- solveBact(pars)
  return(out[nrow(out),2:3])
}
CRL <- modCRL(func=SF,parms=pars,parRange=parRanges[1,])


###################################################
### chunk number 23: crl
###################################################
plot(CRL)


###################################################
### chunk number 24: crlfig
###################################################
plot(CRL)


###################################################
### chunk number 25: 
###################################################
Coll <- collin(SnsBact)
Coll
Coll [Coll[,"collinearity"]<20&Coll[,"N"]==4,]
collin(SnsBact,parset=1:5)


###################################################
### chunk number 26: 
###################################################
Dat<- data.frame(name=c("Obs1","Obs1","Obs2","Obs2"),
                 time=c(1,2,1,2),val=c(50,150,1,2),
                 err=c(5,15,0.1,0.2))
Mod <- Mod <- data.frame(time=0:3,Obs1=rep(4,4),Obs2=1:4)
modCost(mod=Mod,obs=Dat,y="val")


###################################################
### chunk number 27: 
###################################################
modCost(mod=Mod,obs=Dat,y="val",err="err")


###################################################
### chunk number 28: 
###################################################
Data <- matrix (nc=2,byrow=2,data=
c(  2,  0.14,    4,  0.21,    6,  0.31,    8,  0.40,
   10,  0.69,   12,  0.97,   14,  1.42,   16,  2.0,
   18,  3.0,    20,  4.5,    22,  6.5,    24,  9.5,
   26, 13.5,    28, 20.5,    30,  29 , 35, 65, 40, 61)
)
colnames(Data) <- c("time","Bact")
head(Data)


###################################################
### chunk number 29: 
###################################################
Objective <- function (x,parset=names(x))
{
 pars[parset]<- x
 tout    <- seq(0,50,by=0.5)

 # output times
 out <- solveBact(pars,tout)
 # Model cost
 return(modCost(obs=Data,model=out))
}


###################################################
### chunk number 30: 
###################################################
Coll <- collin(sF<-sensFun(func=Objective,parms=pars,varscale=1))
Coll


###################################################
### chunk number 31: coll
###################################################
plot(Coll,log="y")
abline(h=20,col="red")


###################################################
### chunk number 32: collfig
###################################################
plot(Coll,log="y")
abline(h=20,col="red")


###################################################
### chunk number 33: 
###################################################
collin(sF,parset=1:2)


###################################################
### chunk number 34: 
###################################################
print(system.time(Fit<-modFit(p=c(gmax=0.5,eff=0.5),
                  f=Objective,lower=c(0.,0.))))
summary(Fit)


###################################################
### chunk number 35: 
###################################################
 pars[c("gmax","eff")]<- Fit$par
 out   <- solveBact(pars)

 Cost  <- modCost(obs=Data,model=out)
 Cost


###################################################
### chunk number 36: fit
###################################################
 plot(out$time,out$Bact,ylim=range(out$Bact),
     xlab="time, hour",ylab="molC/m3",type="l",lwd=2)
 points(Data,cex=2,pch=18)


###################################################
### chunk number 37: fitfig
###################################################
 plot(out$time,out$Bact,ylim=range(out$Bact),
     xlab="time, hour",ylab="molC/m3",type="l",lwd=2)
 points(Data,cex=2,pch=18)


###################################################
### chunk number 38: res
###################################################
 plot(Cost, xlab="time",ylab="",main="residuals")


###################################################
### chunk number 39: resfig
###################################################
 plot(Cost, xlab="time",ylab="",main="residuals")


###################################################
### chunk number 40: 
###################################################
SF<-summary(Fit)
SF
SF[]
Var0<- SF$modVariance
covIni <-SF$cov.scaled *2.4^2/2
MCMC<-modMCMC(p=coef(Fit),f=Objective,jump=covIni,
              var0=Var0,wvar0=1)


###################################################
### chunk number 41: mcmcplot
###################################################
 plot(MCMC,Full=TRUE)


###################################################
### chunk number 42: mcmcfig
###################################################
 plot(MCMC,Full=TRUE)


###################################################
### chunk number 43: mcmcplot2
###################################################
 pairs(MCMC)


###################################################
### chunk number 44: mcmcfig2
###################################################
 pairs(MCMC)


###################################################
### chunk number 45: 
###################################################
MC <- as.mcmc(MCMC$pars)


###################################################
### chunk number 46: cumuplot
###################################################
cumuplot(MC)


###################################################
### chunk number 47: cumuplot
###################################################
cumuplot(MC)


###################################################
### chunk number 48: 
###################################################
cov(MCMC$pars)
covIni


###################################################
### chunk number 49: dist
###################################################
par(mfrow=c(2,2))
Minmax <- data.frame(min=c(1,2),max=c(2,3))
rownames(Minmax) <-c("par1","par2")
Mean   <- c(par1=1.5,par2=2.5)
Covar  <- matrix(nr=2,data=c(2,2,2,3))
plot(Unif(Minmax,100),main="Unif",xlim=c(1,2),ylim=c(2,3))
plot(Grid(Minmax,100),main="Grid",xlim=c(1,2),ylim=c(2,3))
plot(Latinhyper(Minmax,5),main="Latin hypercube",xlim=c(1,2),ylim=c(2,3))
grid()
plot(Norm(parMean=Mean,parCovar=Covar,num=1000),main="multi normal")


###################################################
### chunk number 50: distfig
###################################################
par(mfrow=c(2,2))
Minmax <- data.frame(min=c(1,2),max=c(2,3))
rownames(Minmax) <-c("par1","par2")
Mean   <- c(par1=1.5,par2=2.5)
Covar  <- matrix(nr=2,data=c(2,2,2,3))
plot(Unif(Minmax,100),main="Unif",xlim=c(1,2),ylim=c(2,3))
plot(Grid(Minmax,100),main="Grid",xlim=c(1,2),ylim=c(2,3))
plot(Latinhyper(Minmax,5),main="Latin hypercube",xlim=c(1,2),ylim=c(2,3))
grid()
plot(Norm(parMean=Mean,parCovar=Covar,num=1000),main="multi normal")


